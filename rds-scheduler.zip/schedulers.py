#!/usr/bin/env python
#
# MIT License
#
# Copyright (c) 2017 Fabrizio Colonna <colofabrix@tin.it>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

from __future__ import print_function

import re
import boto3

from datetime import datetime, timedelta


def timer(tag_value, instance):
    """
    Find the appropriate action for the scheduler type "timer"
    """
    now_time = datetime.now().replace(tzinfo=None)
    split = tag_value.split("/")

    # Interpreting tag
    action = split[0].lower()
    max_duration = datetime.strptime(split[1], '%H%M') - datetime.strptime("0000", "%H%M")

    # Instance up/down time
    instance_state = instance.state['Name'].lower()
    if instance_state == 'running':
        instance_time = instance.launch_time.replace(tzinfo=None)
    elif instance_state == 'stopped':
        stopped_time = re.findall('.*\((.*)\)', instance.state_transition_reason)[0]
        instance_time = datetime.strptime(stopped_time, '%Y-%m-%d %H:%M:%S %Z')
    else:
        return None

    # If the instance must be started or stopped
    if (now_time - instance_time) > max_duration:
        return action

    return None


def startstop(tag_value):
    """
    Find the appropriate action for the scheduler type "startstop"
    """
    # Some useful info
    now_time = datetime.now().time()
    now_weekday = datetime.today().strftime("%a").lower()

    # Extract the parameters
    split = tag_value.split("/")

    # Time the instance has to start
    start_time = split[0]
    if start_time == "":
        start_time = None
    else:
        start_time = datetime.strptime(start_time, '%H%M').time()

    # Time the instance has to stop
    stop_time = split[1]
    if stop_time == "":
        stop_time = None
    else:
        stop_time = datetime.strptime(stop_time, '%H%M').time()

    # Days of the week the scheduler is active
    days_active = split[2].lower()
    if days_active == "weekdays":
        days_active = ['mon', 'tue', 'wed', 'thu', 'fri']
    elif days_active == "weekends":
        days_active = ['sat', 'sun']
    elif days_active == "all":
        days_active = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']
    else:
        days_active = days_active.split("-")

    # Check day of the week
    is_active_day = False
    for d in days_active:
        if d.lower() == now_weekday:
            is_active_day = True
    if not is_active_day:
        return None

    # Check the time spans
    if start_time < stop_time:
        if now_time >= start_time and now_time < stop_time:
            return "start"
        elif now_time >= stop_time:
            return "stop"
    else:
        if now_time >= stop_time and now_time < start_time:
            return "stop"
        elif now_time >= start_time:
            return "start"
    return None


# vim: ft=python:ts=4:sw=4