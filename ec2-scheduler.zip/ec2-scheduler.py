#!/usr/bin/env python
#
# MIT License
#
# Copyright (c) 2017 Fabrizio Colonna <colofabrix@tin.it>
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#

from __future__ import print_function

import re
import boto3
import traceback
import schedulers

from datetime import datetime, timedelta


def lambda_handler(event, context):
    print("Running EC2 Scheduler")

    awsRegions = boto3.client('ec2').describe_regions()['Regions']

    for region in awsRegions:
        print("")
        try:
            instance_actions = {}

            ec2 = boto3.resource('ec2', region_name=region['RegionName'])
            instances = ec2.instances.all()

            print("Working on region \"%s\"" % region['RegionName'])

            for i in instances:
                state = i.state['Name']
                instance_actions.update({i.instance_id: None})

                print("  Instance \"%s\" state is \"%s\"" % (i.instance_id, state))

                if i.tags == None:
                    continue

                for t in i.tags:
                    if t['Key'].startswith("scheduler-"):
                        # Look for the type of scheduler
                        print("    Found scheduler tag with value: \"%s\"" % t['Value'])
                        scheduler_type = t['Key'][len("scheduler-"):]
                        print("    Scheduler type is: %s" % scheduler_type)

                        tag_action = None
                        # Start-Stop scheduler
                        if scheduler_type == "startstop":
                            tag_action = schedulers.startstop(t['Value'])
                        # Alarm Scheduler
                        elif scheduler_type == "timer":
                            tag_action = schedulers.timer(t['Value'], i)
                        # Ignore all schedulers
                        elif scheduler_type == "ignore":
                            instance_actions[i.instance_id] = None
                            continue

                        print("    Tag says: %s" % tag_action)

                        # Check the resulting action
                        print("    Scheduler action is: ", end='')
                        if tag_action == "start" and state == "stopped":
                            instance_actions[i.instance_id] = "start"
                            print("start")
                        elif tag_action == "stop" and state == "running":
                            instance_actions[i.instance_id] = "stop"
                            print("stop")
                        else:
                            print("nothing required")

            # Building start and stop lists
            start_list = []
            stop_list = []
            for i_id, action in instance_actions.iteritems():
                if action is None:
                    continue
                elif action == "start":
                    start_list.append(i_id)
                    print("Added %s to START list" % i_id)
                elif action == "stop":
                    stop_list.append(i_id)
                    print("Added %s to STOP list" % i_id)

            # Execute Start and Stop Commands
            if start_list:
                print("Starting %s instances %s" % (len(start_list), start_list))
                ec2.instances.filter(InstanceIds=start_list).start()
            else:
                print("No Instances to Start")

            if stop_list:
                print("Stopping %s instances %s" % (len(stop_list), stop_list))
                ec2.instances.filter(InstanceIds=stop_list).stop()
            else:
                print("No Instances to Stop")

        except Exception as e:
            print("-" * 60)
            traceback.print_exc()
            print("-" * 60)
            continue


if __name__ == '__main__':
    lambda_handler(None, None)


# vim: ft=python:ts=4:sw=4